define([
        'marionette'
       ],

    function (Marionette) {
        "use strict";

        return new Marionette.Application();
    });
